--
-- PostgreSQL database dump
--

-- Dumped from database version 17.2
-- Dumped by pg_dump version 17.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: apikeystatus; Type: TYPE; Schema: public; Owner: ahmed
--

CREATE TYPE public.apikeystatus AS ENUM (
    'ACTIVE',
    'REVOKED',
    'EXPIRED',
    'SUSPENDED'
);


ALTER TYPE public.apikeystatus OWNER TO ahmed;

--
-- Name: autheventtype; Type: TYPE; Schema: public; Owner: ahmed
--

CREATE TYPE public.autheventtype AS ENUM (
    'LOGIN',
    'LOGOUT',
    'PASSWORD_RESET',
    'TWO_FACTOR_ENABLED',
    'TWO_FACTOR_DISABLED',
    'ACCOUNT_LOCKOUT',
    'SUSPICIOUS_LOGIN',
    'API_KEY_CREATED',
    'API_KEY_REVOKED'
);


ALTER TYPE public.autheventtype OWNER TO ahmed;

--
-- Name: authstatus; Type: TYPE; Schema: public; Owner: ahmed
--

CREATE TYPE public.authstatus AS ENUM (
    'SUCCESS',
    'FAILED',
    'BLOCKED',
    'CHALLENGE',
    'UNAUTHORIZED'
);


ALTER TYPE public.authstatus OWNER TO ahmed;

--
-- Name: loginmethod; Type: TYPE; Schema: public; Owner: ahmed
--

CREATE TYPE public.loginmethod AS ENUM (
    'PASSWORD',
    'SSO',
    'OAUTH',
    'TWO_FACTOR',
    'API_KEY',
    'MAGIC_LINK'
);


ALTER TYPE public.loginmethod OWNER TO ahmed;

--
-- Name: taskpriority; Type: TYPE; Schema: public; Owner: ahmed
--

CREATE TYPE public.taskpriority AS ENUM (
    'LOW',
    'MEDIUM',
    'HIGH',
    'URGENT'
);


ALTER TYPE public.taskpriority OWNER TO ahmed;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ai_models; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.ai_models (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    version character varying(50) NOT NULL,
    type character varying(50) NOT NULL,
    storage_path character varying(512) NOT NULL,
    model_data json,
    status character varying(50) NOT NULL,
    description character varying(500),
    framework character varying(50),
    size_bytes integer,
    is_production boolean NOT NULL,
    is_quantized boolean NOT NULL,
    training_data json,
    hyperparameters json,
    dependencies json,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    last_used_at timestamp with time zone,
    archived_at timestamp with time zone,
    CONSTRAINT ai_models_size_bytes_check CHECK ((size_bytes >= 0))
);


ALTER TABLE public.ai_models OWNER TO ahmed;

--
-- Name: ai_models_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.ai_models_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ai_models_id_seq OWNER TO ahmed;

--
-- Name: ai_models_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.ai_models_id_seq OWNED BY public.ai_models.id;


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO ahmed;

--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.api_keys (
    id integer NOT NULL,
    user_id integer NOT NULL,
    key_hash character varying(255) NOT NULL,
    name character varying(100),
    description character varying(500),
    status public.apikeystatus NOT NULL,
    scopes json,
    last_used_at timestamp with time zone,
    ip_address character varying(45),
    user_agent character varying(255),
    created_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone,
    revoked_at timestamp with time zone
);


ALTER TABLE public.api_keys OWNER TO ahmed;

--
-- Name: api_keys_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.api_keys_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.api_keys_id_seq OWNER TO ahmed;

--
-- Name: api_keys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.api_keys_id_seq OWNED BY public.api_keys.id;


--
-- Name: auth_logs; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.auth_logs (
    id integer NOT NULL,
    user_id integer,
    event_type public.autheventtype NOT NULL,
    status public.authstatus NOT NULL,
    login_method public.loginmethod,
    ip_address character varying(45),
    user_agent character varying(255),
    device_info json,
    country character varying(100),
    region character varying(100),
    city character varying(100),
    latitude character varying(20),
    longitude character varying(20),
    risk_score integer,
    error_message character varying(500),
    is_suspicious boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone
);


ALTER TABLE public.auth_logs OWNER TO ahmed;

--
-- Name: auth_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.auth_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.auth_logs_id_seq OWNER TO ahmed;

--
-- Name: auth_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.auth_logs_id_seq OWNED BY public.auth_logs.id;


--
-- Name: cache_entries; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.cache_entries (
    id integer NOT NULL,
    key character varying(255) NOT NULL,
    value json NOT NULL,
    type character varying(50) NOT NULL,
    created_at timestamp without time zone NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    is_compressed boolean NOT NULL,
    cache_metadata json
);


ALTER TABLE public.cache_entries OWNER TO ahmed;

--
-- Name: cache_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.cache_entries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cache_entries_id_seq OWNER TO ahmed;

--
-- Name: cache_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.cache_entries_id_seq OWNED BY public.cache_entries.id;


--
-- Name: data_archives; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.data_archives (
    id integer NOT NULL,
    original_id integer,
    data_type character varying,
    content json,
    archived_at timestamp without time zone
);


ALTER TABLE public.data_archives OWNER TO ahmed;

--
-- Name: data_archives_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.data_archives_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.data_archives_id_seq OWNER TO ahmed;

--
-- Name: data_archives_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.data_archives_id_seq OWNED BY public.data_archives.id;


--
-- Name: data_requests; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.data_requests (
    id integer NOT NULL,
    user_id integer,
    type character varying,
    data_types json,
    reason character varying,
    status character varying,
    download_url character varying,
    created_at timestamp without time zone,
    completed_at timestamp without time zone
);


ALTER TABLE public.data_requests OWNER TO ahmed;

--
-- Name: data_requests_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.data_requests_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.data_requests_id_seq OWNER TO ahmed;

--
-- Name: data_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.data_requests_id_seq OWNED BY public.data_requests.id;


--
-- Name: device_controls; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.device_controls (
    id integer NOT NULL,
    user_id integer NOT NULL,
    device_id character varying(100) NOT NULL,
    action character varying(50) NOT NULL,
    parameters json,
    result json,
    status character varying(50) NOT NULL,
    error_message character varying(500),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    device_type character varying(50) NOT NULL,
    device_name character varying(100),
    device_data json,
    is_success boolean NOT NULL,
    retry_count integer NOT NULL,
    duration_ms integer
);


ALTER TABLE public.device_controls OWNER TO ahmed;

--
-- Name: device_controls_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.device_controls_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.device_controls_id_seq OWNER TO ahmed;

--
-- Name: device_controls_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.device_controls_id_seq OWNED BY public.device_controls.id;


--
-- Name: emotional_health; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.emotional_health (
    id integer NOT NULL,
    user_id integer NOT NULL,
    emotion_type character varying(50) NOT NULL,
    intensity double precision NOT NULL,
    duration integer,
    trigger character varying(100),
    emotional_data json,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.emotional_health OWNER TO ahmed;

--
-- Name: emotional_health_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.emotional_health_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.emotional_health_id_seq OWNER TO ahmed;

--
-- Name: emotional_health_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.emotional_health_id_seq OWNED BY public.emotional_health.id;


--
-- Name: feedback; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.feedback (
    id integer NOT NULL,
    user_id integer,
    type character varying,
    content character varying,
    category character varying,
    context json,
    priority character varying,
    status character varying,
    resolution_notes character varying,
    resolved_by integer,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    resolved_at timestamp without time zone
);


ALTER TABLE public.feedback OWNER TO ahmed;

--
-- Name: feedback_comments; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.feedback_comments (
    id integer NOT NULL,
    feedback_id integer,
    user_id integer,
    content character varying,
    created_at timestamp without time zone
);


ALTER TABLE public.feedback_comments OWNER TO ahmed;

--
-- Name: feedback_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.feedback_comments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.feedback_comments_id_seq OWNER TO ahmed;

--
-- Name: feedback_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.feedback_comments_id_seq OWNED BY public.feedback_comments.id;


--
-- Name: feedback_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.feedback_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.feedback_id_seq OWNER TO ahmed;

--
-- Name: feedback_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.feedback_id_seq OWNED BY public.feedback.id;


--
-- Name: files; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.files (
    id integer NOT NULL,
    user_id integer NOT NULL,
    filename character varying(255) NOT NULL,
    file_path character varying(1000) NOT NULL,
    file_type character varying(50) NOT NULL,
    file_size integer NOT NULL,
    mime_type character varying(100) NOT NULL,
    hash character varying(64),
    file_data json,
    is_deleted boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    deleted_at timestamp with time zone,
    description character varying(500),
    tags json,
    is_public boolean NOT NULL,
    download_count integer NOT NULL,
    CONSTRAINT files_file_size_check CHECK ((file_size >= 0))
);


ALTER TABLE public.files OWNER TO ahmed;

--
-- Name: files_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.files_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.files_id_seq OWNER TO ahmed;

--
-- Name: files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.files_id_seq OWNED BY public.files.id;


--
-- Name: health_metrics; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.health_metrics (
    id integer NOT NULL,
    user_id integer NOT NULL,
    metric_type character varying(50) NOT NULL,
    value double precision NOT NULL,
    unit character varying(20),
    health_data json,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.health_metrics OWNER TO ahmed;

--
-- Name: health_metrics_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.health_metrics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.health_metrics_id_seq OWNER TO ahmed;

--
-- Name: health_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.health_metrics_id_seq OWNED BY public.health_metrics.id;


--
-- Name: model_metrics; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.model_metrics (
    id integer NOT NULL,
    model_id integer NOT NULL,
    metric_name character varying(100) NOT NULL,
    metric_value double precision NOT NULL,
    metric_type character varying(50) NOT NULL,
    dataset_name character varying(100),
    split_name character varying(50),
    metric_data json,
    "timestamp" timestamp with time zone NOT NULL
);


ALTER TABLE public.model_metrics OWNER TO ahmed;

--
-- Name: model_metrics_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.model_metrics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.model_metrics_id_seq OWNER TO ahmed;

--
-- Name: model_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.model_metrics_id_seq OWNED BY public.model_metrics.id;


--
-- Name: model_usage_logs; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.model_usage_logs (
    id integer NOT NULL,
    model_id integer NOT NULL,
    user_id integer NOT NULL,
    task_type character varying(100) NOT NULL,
    input_data json,
    output_data json,
    execution_time_ms integer NOT NULL,
    memory_usage_mb double precision,
    cpu_usage_percent double precision,
    gpu_usage_percent double precision,
    status character varying(50) NOT NULL,
    error_message character varying(512),
    batch_size integer,
    is_cached boolean NOT NULL,
    cache_hit_rate double precision,
    created_at timestamp with time zone NOT NULL,
    CONSTRAINT model_usage_logs_batch_size_check CHECK ((batch_size > 0)),
    CONSTRAINT model_usage_logs_cache_hit_rate_check CHECK (((cache_hit_rate >= (0)::double precision) AND (cache_hit_rate <= (1)::double precision))),
    CONSTRAINT model_usage_logs_cpu_usage_percent_check CHECK (((cpu_usage_percent >= (0)::double precision) AND (cpu_usage_percent <= (100)::double precision))),
    CONSTRAINT model_usage_logs_execution_time_ms_check CHECK ((execution_time_ms >= 0)),
    CONSTRAINT model_usage_logs_gpu_usage_percent_check CHECK (((gpu_usage_percent >= (0)::double precision) AND (gpu_usage_percent <= (100)::double precision))),
    CONSTRAINT model_usage_logs_memory_usage_mb_check CHECK ((memory_usage_mb >= (0)::double precision))
);


ALTER TABLE public.model_usage_logs OWNER TO ahmed;

--
-- Name: model_usage_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.model_usage_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.model_usage_logs_id_seq OWNER TO ahmed;

--
-- Name: model_usage_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.model_usage_logs_id_seq OWNED BY public.model_usage_logs.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.notifications (
    id integer NOT NULL,
    user_id integer NOT NULL,
    notification_type character varying(50) NOT NULL,
    title character varying(255) NOT NULL,
    message character varying(1000),
    notification_data json,
    is_read boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    read_at timestamp with time zone
);


ALTER TABLE public.notifications OWNER TO ahmed;

--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notifications_id_seq OWNER TO ahmed;

--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: password_resets; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.password_resets (
    id integer NOT NULL,
    user_id integer NOT NULL,
    reset_token character varying NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    used_at timestamp with time zone,
    ip_address character varying
);


ALTER TABLE public.password_resets OWNER TO ahmed;

--
-- Name: password_resets_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.password_resets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.password_resets_id_seq OWNER TO ahmed;

--
-- Name: password_resets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.password_resets_id_seq OWNED BY public.password_resets.id;


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.permissions (
    id integer NOT NULL,
    name character varying NOT NULL,
    description character varying,
    resource character varying NOT NULL,
    action character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.permissions OWNER TO ahmed;

--
-- Name: permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.permissions_id_seq OWNER TO ahmed;

--
-- Name: permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.permissions_id_seq OWNED BY public.permissions.id;


--
-- Name: privacy_settings; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.privacy_settings (
    id integer NOT NULL,
    user_id integer,
    data_collection boolean,
    data_sharing boolean,
    marketing_communications boolean,
    analytics_tracking boolean,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.privacy_settings OWNER TO ahmed;

--
-- Name: privacy_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.privacy_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.privacy_settings_id_seq OWNER TO ahmed;

--
-- Name: privacy_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.privacy_settings_id_seq OWNED BY public.privacy_settings.id;


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.role_permissions (
    role_id integer NOT NULL,
    permission_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.role_permissions OWNER TO ahmed;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    name character varying NOT NULL,
    description character varying,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.roles OWNER TO ahmed;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.roles_id_seq OWNER TO ahmed;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.sessions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    session_token character varying(255) NOT NULL,
    refresh_token character varying(255),
    is_active boolean NOT NULL,
    device_info json,
    ip_address character varying(45),
    user_agent character varying(255),
    created_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    ended_at timestamp with time zone
);


ALTER TABLE public.sessions OWNER TO ahmed;

--
-- Name: sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sessions_id_seq OWNER TO ahmed;

--
-- Name: sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.sessions_id_seq OWNED BY public.sessions.id;


--
-- Name: summaries; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.summaries (
    id integer NOT NULL,
    task_id integer NOT NULL,
    summary_type character varying(50) NOT NULL,
    content text NOT NULL,
    key_points json,
    summary_data json,
    word_count integer NOT NULL,
    is_draft boolean NOT NULL,
    model_version character varying(50),
    confidence_score double precision,
    language character varying(10) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    last_validated_at timestamp with time zone
);


ALTER TABLE public.summaries OWNER TO ahmed;

--
-- Name: summaries_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.summaries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.summaries_id_seq OWNER TO ahmed;

--
-- Name: summaries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.summaries_id_seq OWNED BY public.summaries.id;


--
-- Name: summarized_content; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.summarized_content (
    id integer NOT NULL,
    content_type character varying NOT NULL,
    content_id integer NOT NULL,
    summary text NOT NULL,
    language character varying,
    model_version character varying,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.summarized_content OWNER TO ahmed;

--
-- Name: summarized_content_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.summarized_content_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.summarized_content_id_seq OWNER TO ahmed;

--
-- Name: summarized_content_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.summarized_content_id_seq OWNED BY public.summarized_content.id;


--
-- Name: system_logs; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.system_logs (
    id integer NOT NULL,
    user_id integer,
    action character varying(100) NOT NULL,
    details json,
    severity character varying(20) NOT NULL,
    source character varying(50) NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    ip_address character varying(45),
    user_agent character varying(500),
    status character varying(20) NOT NULL,
    log_data json
);


ALTER TABLE public.system_logs OWNER TO ahmed;

--
-- Name: system_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.system_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.system_logs_id_seq OWNER TO ahmed;

--
-- Name: system_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.system_logs_id_seq OWNED BY public.system_logs.id;


--
-- Name: tags; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.tags (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    description text,
    color_code character varying(7),
    created_by integer,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.tags OWNER TO ahmed;

--
-- Name: tags_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.tags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tags_id_seq OWNER TO ahmed;

--
-- Name: tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.tags_id_seq OWNED BY public.tags.id;


--
-- Name: task_attachments; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.task_attachments (
    id integer NOT NULL,
    task_id integer NOT NULL,
    user_id integer NOT NULL,
    filename character varying NOT NULL,
    file_path character varying NOT NULL,
    file_size integer,
    mime_type character varying,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.task_attachments OWNER TO ahmed;

--
-- Name: task_attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.task_attachments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.task_attachments_id_seq OWNER TO ahmed;

--
-- Name: task_attachments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.task_attachments_id_seq OWNED BY public.task_attachments.id;


--
-- Name: task_categories; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.task_categories (
    id integer NOT NULL,
    name character varying NOT NULL,
    description character varying,
    color character varying,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.task_categories OWNER TO ahmed;

--
-- Name: task_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.task_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.task_categories_id_seq OWNER TO ahmed;

--
-- Name: task_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.task_categories_id_seq OWNED BY public.task_categories.id;


--
-- Name: task_comments; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.task_comments (
    id integer NOT NULL,
    task_id integer NOT NULL,
    user_id integer NOT NULL,
    content text NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.task_comments OWNER TO ahmed;

--
-- Name: task_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.task_comments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.task_comments_id_seq OWNER TO ahmed;

--
-- Name: task_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.task_comments_id_seq OWNED BY public.task_comments.id;


--
-- Name: task_history; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.task_history (
    id integer NOT NULL,
    task_id integer NOT NULL,
    user_id integer NOT NULL,
    action character varying NOT NULL,
    field character varying,
    old_value character varying,
    new_value character varying,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.task_history OWNER TO ahmed;

--
-- Name: task_history_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.task_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.task_history_id_seq OWNER TO ahmed;

--
-- Name: task_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.task_history_id_seq OWNED BY public.task_history.id;


--
-- Name: task_statuses; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.task_statuses (
    id integer NOT NULL,
    name character varying NOT NULL,
    description character varying,
    color character varying,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.task_statuses OWNER TO ahmed;

--
-- Name: task_statuses_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.task_statuses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.task_statuses_id_seq OWNER TO ahmed;

--
-- Name: task_statuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.task_statuses_id_seq OWNED BY public.task_statuses.id;


--
-- Name: task_tags; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.task_tags (
    task_id integer NOT NULL,
    tag_id integer NOT NULL
);


ALTER TABLE public.task_tags OWNER TO ahmed;

--
-- Name: tasks; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.tasks (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    user_id integer NOT NULL,
    assignee_id integer,
    status_id integer NOT NULL,
    category_id integer,
    workflow_id integer,
    _priority public.taskpriority NOT NULL,
    due_date timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone,
    completed_at timestamp with time zone,
    creator_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.tasks OWNER TO ahmed;

--
-- Name: tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tasks_id_seq OWNER TO ahmed;

--
-- Name: tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.tasks_id_seq OWNED BY public.tasks.id;


--
-- Name: user_preferences; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.user_preferences (
    id integer NOT NULL,
    user_id integer NOT NULL,
    theme character varying(20) NOT NULL,
    language character varying(10) NOT NULL,
    notifications_enabled boolean NOT NULL,
    accessibility_settings json,
    workflow_preferences json,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.user_preferences OWNER TO ahmed;

--
-- Name: user_preferences_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.user_preferences_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_preferences_id_seq OWNER TO ahmed;

--
-- Name: user_preferences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.user_preferences_id_seq OWNED BY public.user_preferences.id;


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.user_roles (
    id integer NOT NULL,
    user_id integer NOT NULL,
    role_id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.user_roles OWNER TO ahmed;

--
-- Name: user_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.user_roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_roles_id_seq OWNER TO ahmed;

--
-- Name: user_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.user_roles_id_seq OWNED BY public.user_roles.id;


--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.user_sessions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    session_token character varying NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    last_activity timestamp with time zone DEFAULT now(),
    ip_address character varying,
    user_agent character varying
);


ALTER TABLE public.user_sessions OWNER TO ahmed;

--
-- Name: user_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.user_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_sessions_id_seq OWNER TO ahmed;

--
-- Name: user_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.user_sessions_id_seq OWNED BY public.user_sessions.id;


--
-- Name: user_settings; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.user_settings (
    id integer NOT NULL,
    user_id integer NOT NULL,
    setting_key character varying(100) NOT NULL,
    setting_value json NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.user_settings OWNER TO ahmed;

--
-- Name: user_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.user_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_settings_id_seq OWNER TO ahmed;

--
-- Name: user_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.user_settings_id_seq OWNED BY public.user_settings.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying NOT NULL,
    username character varying NOT NULL,
    hashed_password character varying NOT NULL,
    full_name character varying NOT NULL,
    is_active boolean NOT NULL,
    is_verified boolean NOT NULL,
    is_locked boolean NOT NULL,
    locked_until timestamp with time zone,
    failed_login_attempts integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    last_login timestamp with time zone
);


ALTER TABLE public.users OWNER TO ahmed;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO ahmed;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: web_search_queries; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.web_search_queries (
    id integer NOT NULL,
    user_id integer NOT NULL,
    query_text text NOT NULL,
    search_type character varying(50) NOT NULL,
    filters json,
    results json,
    result_count integer NOT NULL,
    execution_time double precision NOT NULL,
    "timestamp" timestamp without time zone NOT NULL
);


ALTER TABLE public.web_search_queries OWNER TO ahmed;

--
-- Name: web_search_queries_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.web_search_queries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.web_search_queries_id_seq OWNER TO ahmed;

--
-- Name: web_search_queries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.web_search_queries_id_seq OWNED BY public.web_search_queries.id;


--
-- Name: web_searches; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.web_searches (
    id integer NOT NULL,
    user_id integer NOT NULL,
    query character varying(1000) NOT NULL,
    search_provider character varying(50) NOT NULL,
    results_count integer,
    search_data json,
    is_cached boolean NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.web_searches OWNER TO ahmed;

--
-- Name: web_searches_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.web_searches_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.web_searches_id_seq OWNER TO ahmed;

--
-- Name: web_searches_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.web_searches_id_seq OWNED BY public.web_searches.id;


--
-- Name: workflow_step_transitions; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.workflow_step_transitions (
    id integer NOT NULL,
    from_step_id integer NOT NULL,
    to_step_id integer NOT NULL,
    condition text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.workflow_step_transitions OWNER TO ahmed;

--
-- Name: workflow_step_transitions_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.workflow_step_transitions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.workflow_step_transitions_id_seq OWNER TO ahmed;

--
-- Name: workflow_step_transitions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.workflow_step_transitions_id_seq OWNED BY public.workflow_step_transitions.id;


--
-- Name: workflow_steps; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.workflow_steps (
    id integer NOT NULL,
    workflow_id integer NOT NULL,
    name character varying NOT NULL,
    description text,
    step_order integer NOT NULL,
    is_required boolean,
    is_automated boolean,
    automation_config text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.workflow_steps OWNER TO ahmed;

--
-- Name: workflow_steps_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.workflow_steps_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.workflow_steps_id_seq OWNER TO ahmed;

--
-- Name: workflow_steps_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.workflow_steps_id_seq OWNED BY public.workflow_steps.id;


--
-- Name: workflows; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.workflows (
    id integer NOT NULL,
    name character varying NOT NULL,
    description text,
    is_active boolean,
    creator_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.workflows OWNER TO ahmed;

--
-- Name: workflows_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.workflows_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.workflows_id_seq OWNER TO ahmed;

--
-- Name: workflows_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.workflows_id_seq OWNED BY public.workflows.id;


--
-- Name: ai_models id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.ai_models ALTER COLUMN id SET DEFAULT nextval('public.ai_models_id_seq'::regclass);


--
-- Name: api_keys id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.api_keys ALTER COLUMN id SET DEFAULT nextval('public.api_keys_id_seq'::regclass);


--
-- Name: auth_logs id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.auth_logs ALTER COLUMN id SET DEFAULT nextval('public.auth_logs_id_seq'::regclass);


--
-- Name: cache_entries id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.cache_entries ALTER COLUMN id SET DEFAULT nextval('public.cache_entries_id_seq'::regclass);


--
-- Name: data_archives id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.data_archives ALTER COLUMN id SET DEFAULT nextval('public.data_archives_id_seq'::regclass);


--
-- Name: data_requests id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.data_requests ALTER COLUMN id SET DEFAULT nextval('public.data_requests_id_seq'::regclass);


--
-- Name: device_controls id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.device_controls ALTER COLUMN id SET DEFAULT nextval('public.device_controls_id_seq'::regclass);


--
-- Name: emotional_health id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.emotional_health ALTER COLUMN id SET DEFAULT nextval('public.emotional_health_id_seq'::regclass);


--
-- Name: feedback id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.feedback ALTER COLUMN id SET DEFAULT nextval('public.feedback_id_seq'::regclass);


--
-- Name: feedback_comments id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.feedback_comments ALTER COLUMN id SET DEFAULT nextval('public.feedback_comments_id_seq'::regclass);


--
-- Name: files id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.files ALTER COLUMN id SET DEFAULT nextval('public.files_id_seq'::regclass);


--
-- Name: health_metrics id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.health_metrics ALTER COLUMN id SET DEFAULT nextval('public.health_metrics_id_seq'::regclass);


--
-- Name: model_metrics id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.model_metrics ALTER COLUMN id SET DEFAULT nextval('public.model_metrics_id_seq'::regclass);


--
-- Name: model_usage_logs id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.model_usage_logs ALTER COLUMN id SET DEFAULT nextval('public.model_usage_logs_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: password_resets id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.password_resets ALTER COLUMN id SET DEFAULT nextval('public.password_resets_id_seq'::regclass);


--
-- Name: permissions id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.permissions ALTER COLUMN id SET DEFAULT nextval('public.permissions_id_seq'::regclass);


--
-- Name: privacy_settings id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.privacy_settings ALTER COLUMN id SET DEFAULT nextval('public.privacy_settings_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: sessions id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.sessions ALTER COLUMN id SET DEFAULT nextval('public.sessions_id_seq'::regclass);


--
-- Name: summaries id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.summaries ALTER COLUMN id SET DEFAULT nextval('public.summaries_id_seq'::regclass);


--
-- Name: summarized_content id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.summarized_content ALTER COLUMN id SET DEFAULT nextval('public.summarized_content_id_seq'::regclass);


--
-- Name: system_logs id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.system_logs ALTER COLUMN id SET DEFAULT nextval('public.system_logs_id_seq'::regclass);


--
-- Name: tags id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.tags ALTER COLUMN id SET DEFAULT nextval('public.tags_id_seq'::regclass);


--
-- Name: task_attachments id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.task_attachments ALTER COLUMN id SET DEFAULT nextval('public.task_attachments_id_seq'::regclass);


--
-- Name: task_categories id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.task_categories ALTER COLUMN id SET DEFAULT nextval('public.task_categories_id_seq'::regclass);


--
-- Name: task_comments id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.task_comments ALTER COLUMN id SET DEFAULT nextval('public.task_comments_id_seq'::regclass);


--
-- Name: task_history id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.task_history ALTER COLUMN id SET DEFAULT nextval('public.task_history_id_seq'::regclass);


--
-- Name: task_statuses id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.task_statuses ALTER COLUMN id SET DEFAULT nextval('public.task_statuses_id_seq'::regclass);


--
-- Name: tasks id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.tasks ALTER COLUMN id SET DEFAULT nextval('public.tasks_id_seq'::regclass);


--
-- Name: user_preferences id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.user_preferences ALTER COLUMN id SET DEFAULT nextval('public.user_preferences_id_seq'::regclass);


--
-- Name: user_roles id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.user_roles ALTER COLUMN id SET DEFAULT nextval('public.user_roles_id_seq'::regclass);


--
-- Name: user_sessions id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.user_sessions ALTER COLUMN id SET DEFAULT nextval('public.user_sessions_id_seq'::regclass);


--
-- Name: user_settings id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.user_settings ALTER COLUMN id SET DEFAULT nextval('public.user_settings_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: web_search_queries id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.web_search_queries ALTER COLUMN id SET DEFAULT nextval('public.web_search_queries_id_seq'::regclass);


--
-- Name: web_searches id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.web_searches ALTER COLUMN id SET DEFAULT nextval('public.web_searches_id_seq'::regclass);


--
-- Name: workflow_step_transitions id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.workflow_step_transitions ALTER COLUMN id SET DEFAULT nextval('public.workflow_step_transitions_id_seq'::regclass);


--
-- Name: workflow_steps id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.workflow_steps ALTER COLUMN id SET DEFAULT nextval('public.workflow_steps_id_seq'::regclass);


--
-- Name: workflows id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.workflows ALTER COLUMN id SET DEFAULT nextval('public.workflows_id_seq'::regclass);


--
-- Data for Name: ai_models; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.ai_models (id, name, version, type, storage_path, model_data, status, description, framework, size_bytes, is_production, is_quantized, training_data, hyperparameters, dependencies, created_at, updated_at, last_used_at, archived_at) FROM stdin;
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.alembic_version (version_num) FROM stdin;
\.


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.api_keys (id, user_id, key_hash, name, description, status, scopes, last_used_at, ip_address, user_agent, created_at, expires_at, revoked_at) FROM stdin;
\.


--
-- Data for Name: auth_logs; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.auth_logs (id, user_id, event_type, status, login_method, ip_address, user_agent, device_info, country, region, city, latitude, longitude, risk_score, error_message, is_suspicious, created_at, expires_at) FROM stdin;
\.


--
-- Data for Name: cache_entries; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.cache_entries (id, key, value, type, created_at, expires_at, is_compressed, cache_metadata) FROM stdin;
\.


--
-- Data for Name: data_archives; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.data_archives (id, original_id, data_type, content, archived_at) FROM stdin;
\.


--
-- Data for Name: data_requests; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.data_requests (id, user_id, type, data_types, reason, status, download_url, created_at, completed_at) FROM stdin;
\.


--
-- Data for Name: device_controls; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.device_controls (id, user_id, device_id, action, parameters, result, status, error_message, created_at, updated_at, device_type, device_name, device_data, is_success, retry_count, duration_ms) FROM stdin;
\.


--
-- Data for Name: emotional_health; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.emotional_health (id, user_id, emotion_type, intensity, duration, trigger, emotional_data, created_at) FROM stdin;
\.


--
-- Data for Name: feedback; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.feedback (id, user_id, type, content, category, context, priority, status, resolution_notes, resolved_by, created_at, updated_at, resolved_at) FROM stdin;
\.


--
-- Data for Name: feedback_comments; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.feedback_comments (id, feedback_id, user_id, content, created_at) FROM stdin;
\.


--
-- Data for Name: files; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.files (id, user_id, filename, file_path, file_type, file_size, mime_type, hash, file_data, is_deleted, created_at, updated_at, deleted_at, description, tags, is_public, download_count) FROM stdin;
\.


--
-- Data for Name: health_metrics; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.health_metrics (id, user_id, metric_type, value, unit, health_data, created_at) FROM stdin;
\.


--
-- Data for Name: model_metrics; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.model_metrics (id, model_id, metric_name, metric_value, metric_type, dataset_name, split_name, metric_data, "timestamp") FROM stdin;
\.


--
-- Data for Name: model_usage_logs; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.model_usage_logs (id, model_id, user_id, task_type, input_data, output_data, execution_time_ms, memory_usage_mb, cpu_usage_percent, gpu_usage_percent, status, error_message, batch_size, is_cached, cache_hit_rate, created_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.notifications (id, user_id, notification_type, title, message, notification_data, is_read, created_at, read_at) FROM stdin;
\.


--
-- Data for Name: password_resets; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.password_resets (id, user_id, reset_token, expires_at, created_at, used_at, ip_address) FROM stdin;
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.permissions (id, name, description, resource, action, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: privacy_settings; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.privacy_settings (id, user_id, data_collection, data_sharing, marketing_communications, analytics_tracking, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.role_permissions (role_id, permission_id, created_at) FROM stdin;
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.roles (id, name, description, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.sessions (id, user_id, session_token, refresh_token, is_active, device_info, ip_address, user_agent, created_at, expires_at, ended_at) FROM stdin;
\.


--
-- Data for Name: summaries; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.summaries (id, task_id, summary_type, content, key_points, summary_data, word_count, is_draft, model_version, confidence_score, language, created_at, updated_at, last_validated_at) FROM stdin;
\.


--
-- Data for Name: summarized_content; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.summarized_content (id, content_type, content_id, summary, language, model_version, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: system_logs; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.system_logs (id, user_id, action, details, severity, source, "timestamp", ip_address, user_agent, status, log_data) FROM stdin;
\.


--
-- Data for Name: tags; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.tags (id, name, description, color_code, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: task_attachments; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.task_attachments (id, task_id, user_id, filename, file_path, file_size, mime_type, created_at) FROM stdin;
\.


--
-- Data for Name: task_categories; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.task_categories (id, name, description, color, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: task_comments; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.task_comments (id, task_id, user_id, content, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: task_history; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.task_history (id, task_id, user_id, action, field, old_value, new_value, created_at) FROM stdin;
\.


--
-- Data for Name: task_statuses; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.task_statuses (id, name, description, color, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: task_tags; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.task_tags (task_id, tag_id) FROM stdin;
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.tasks (id, title, description, user_id, assignee_id, status_id, category_id, workflow_id, _priority, due_date, created_at, updated_at, completed_at, creator_id) FROM stdin;
\.


--
-- Data for Name: user_preferences; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.user_preferences (id, user_id, theme, language, notifications_enabled, accessibility_settings, workflow_preferences, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.user_roles (id, user_id, role_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.user_sessions (id, user_id, session_token, expires_at, created_at, last_activity, ip_address, user_agent) FROM stdin;
\.


--
-- Data for Name: user_settings; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.user_settings (id, user_id, setting_key, setting_value, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.users (id, email, username, hashed_password, full_name, is_active, is_verified, is_locked, locked_until, failed_login_attempts, created_at, updated_at, last_login) FROM stdin;
\.


--
-- Data for Name: web_search_queries; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.web_search_queries (id, user_id, query_text, search_type, filters, results, result_count, execution_time, "timestamp") FROM stdin;
\.


--
-- Data for Name: web_searches; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.web_searches (id, user_id, query, search_provider, results_count, search_data, is_cached, created_at) FROM stdin;
\.


--
-- Data for Name: workflow_step_transitions; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.workflow_step_transitions (id, from_step_id, to_step_id, condition, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: workflow_steps; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.workflow_steps (id, workflow_id, name, description, step_order, is_required, is_automated, automation_config, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: workflows; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.workflows (id, name, description, is_active, creator_id, created_at, updated_at) FROM stdin;
\.


--
-- Name: ai_models_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.ai_models_id_seq', 1, false);


--
-- Name: api_keys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.api_keys_id_seq', 1, false);


--
-- Name: auth_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.auth_logs_id_seq', 1, false);


--
-- Name: cache_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.cache_entries_id_seq', 1, false);


--
-- Name: data_archives_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.data_archives_id_seq', 1, false);


--
-- Name: data_requests_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.data_requests_id_seq', 1, false);


--
-- Name: device_controls_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.device_controls_id_seq', 1, false);


--
-- Name: emotional_health_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.emotional_health_id_seq', 1, false);


--
-- Name: feedback_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.feedback_comments_id_seq', 1, false);


--
-- Name: feedback_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.feedback_id_seq', 1, false);


--
-- Name: files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.files_id_seq', 1, false);


--
-- Name: health_metrics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.health_metrics_id_seq', 1, false);


--
-- Name: model_metrics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.model_metrics_id_seq', 1, false);


--
-- Name: model_usage_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.model_usage_logs_id_seq', 1, false);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.notifications_id_seq', 1, false);


--
-- Name: password_resets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.password_resets_id_seq', 1, false);


--
-- Name: permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.permissions_id_seq', 1, false);


--
-- Name: privacy_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.privacy_settings_id_seq', 1, false);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.roles_id_seq', 1, false);


--
-- Name: sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.sessions_id_seq', 1, false);


--
-- Name: summaries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.summaries_id_seq', 1, false);


--
-- Name: summarized_content_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.summarized_content_id_seq', 1, false);


--
-- Name: system_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.system_logs_id_seq', 1, false);


--
-- Name: tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.tags_id_seq', 1, false);


--
-- Name: task_attachments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.task_attachments_id_seq', 1, false);


--
-- Name: task_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.task_categories_id_seq', 1, false);


--
-- Name: task_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.task_comments_id_seq', 1, false);


--
-- Name: task_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.task_history_id_seq', 1, false);


--
-- Name: task_statuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.task_statuses_id_seq', 1, false);


--
-- Name: tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.tasks_id_seq', 1, false);


--
-- Name: user_preferences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.user_preferences_id_seq', 1, false);


--
-- Name: user_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.user_roles_id_seq', 1, false);


--
-- Name: user_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.user_sessions_id_seq', 1, false);


--
-- Name: user_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.user_settings_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: web_search_queries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.web_search_queries_id_seq', 1, false);


--
-- Name: web_searches_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.web_searches_id_seq', 1, false);


--
-- Name: workflow_step_transitions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.workflow_step_transitions_id_seq', 1, false);


--
-- Name: workflow_steps_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.workflow_steps_id_seq', 1, false);


--
-- Name: workflows_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.workflows_id_seq', 1, false);


--
-- Name: ai_models ai_models_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.ai_models
    ADD CONSTRAINT ai_models_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: api_keys api_keys_key_hash_key; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_key_hash_key UNIQUE (key_hash);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: auth_logs auth_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.auth_logs
    ADD CONSTRAINT auth_logs_pkey PRIMARY KEY (id);


--
-- Name: cache_entries cache_entries_key_key; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.cache_entries
    ADD CONSTRAINT cache_entries_key_key UNIQUE (key);


--
-- Name: cache_entries cache_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.cache_entries
    ADD CONSTRAINT cache_entries_pkey PRIMARY KEY (id);


--
-- Name: data_archives data_archives_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.data_archives
    ADD CONSTRAINT data_archives_pkey PRIMARY KEY (id);


--
-- Name: data_requests data_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.data_requests
    ADD CONSTRAINT data_requests_pkey PRIMARY KEY (id);


--
-- Name: device_controls device_controls_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.device_controls
    ADD CONSTRAINT device_controls_pkey PRIMARY KEY (id);


--
-- Name: emotional_health emotional_health_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.emotional_health
    ADD CONSTRAINT emotional_health_pkey PRIMARY KEY (id);


--
-- Name: feedback_comments feedback_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.feedback_comments
    ADD CONSTRAINT feedback_comments_pkey PRIMARY KEY (id);


--
-- Name: feedback feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_pkey PRIMARY KEY (id);


--
-- Name: files files_file_path_key; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.files
    ADD CONSTRAINT files_file_path_key UNIQUE (file_path);


--
-- Name: files files_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.files
    ADD CONSTRAINT files_pkey PRIMARY KEY (id);


--
-- Name: health_metrics health_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.health_metrics
    ADD CONSTRAINT health_metrics_pkey PRIMARY KEY (id);


--
-- Name: model_metrics model_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.model_metrics
    ADD CONSTRAINT model_metrics_pkey PRIMARY KEY (id);


--
-- Name: model_usage_logs model_usage_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.model_usage_logs
    ADD CONSTRAINT model_usage_logs_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: password_resets password_resets_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.password_resets
    ADD CONSTRAINT password_resets_pkey PRIMARY KEY (id);


--
-- Name: password_resets password_resets_reset_token_key; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.password_resets
    ADD CONSTRAINT password_resets_reset_token_key UNIQUE (reset_token);


--
-- Name: permissions permissions_name_key; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_name_key UNIQUE (name);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: privacy_settings privacy_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.privacy_settings
    ADD CONSTRAINT privacy_settings_pkey PRIMARY KEY (id);


--
-- Name: privacy_settings privacy_settings_user_id_key; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.privacy_settings
    ADD CONSTRAINT privacy_settings_user_id_key UNIQUE (user_id);


--
-- Name: roles roles_name_key; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key UNIQUE (name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_refresh_token_key; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_refresh_token_key UNIQUE (refresh_token);


--
-- Name: sessions sessions_session_token_key; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_session_token_key UNIQUE (session_token);


--
-- Name: summaries summaries_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.summaries
    ADD CONSTRAINT summaries_pkey PRIMARY KEY (id);


--
-- Name: summaries summaries_task_id_key; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.summaries
    ADD CONSTRAINT summaries_task_id_key UNIQUE (task_id);


--
-- Name: summarized_content summarized_content_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.summarized_content
    ADD CONSTRAINT summarized_content_pkey PRIMARY KEY (id);


--
-- Name: system_logs system_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.system_logs
    ADD CONSTRAINT system_logs_pkey PRIMARY KEY (id);


--
-- Name: tags tags_name_key; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_name_key UNIQUE (name);


--
-- Name: tags tags_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (id);


--
-- Name: task_attachments task_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.task_attachments
    ADD CONSTRAINT task_attachments_pkey PRIMARY KEY (id);


--
-- Name: task_categories task_categories_name_key; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.task_categories
    ADD CONSTRAINT task_categories_name_key UNIQUE (name);


--
-- Name: task_categories task_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.task_categories
    ADD CONSTRAINT task_categories_pkey PRIMARY KEY (id);


--
-- Name: task_comments task_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.task_comments
    ADD CONSTRAINT task_comments_pkey PRIMARY KEY (id);


--
-- Name: task_history task_history_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.task_history
    ADD CONSTRAINT task_history_pkey PRIMARY KEY (id);


--
-- Name: task_statuses task_statuses_name_key; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.task_statuses
    ADD CONSTRAINT task_statuses_name_key UNIQUE (name);


--
-- Name: task_statuses task_statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.task_statuses
    ADD CONSTRAINT task_statuses_pkey PRIMARY KEY (id);


--
-- Name: task_tags task_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.task_tags
    ADD CONSTRAINT task_tags_pkey PRIMARY KEY (task_id, tag_id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: role_permissions unique_role_permission; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT unique_role_permission PRIMARY KEY (role_id, permission_id);


--
-- Name: workflow_step_transitions unique_step_transition; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.workflow_step_transitions
    ADD CONSTRAINT unique_step_transition UNIQUE (from_step_id, to_step_id);


--
-- Name: workflow_steps unique_workflow_step_order; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.workflow_steps
    ADD CONSTRAINT unique_workflow_step_order UNIQUE (workflow_id, step_order);


--
-- Name: tasks uq_task_title_user; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT uq_task_title_user UNIQUE (title, user_id);


--
-- Name: user_settings uq_user_settings_user_key; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.user_settings
    ADD CONSTRAINT uq_user_settings_user_key UNIQUE (user_id, setting_key);


--
-- Name: user_preferences user_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.user_preferences
    ADD CONSTRAINT user_preferences_pkey PRIMARY KEY (id);


--
-- Name: user_preferences user_preferences_user_id_key; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.user_preferences
    ADD CONSTRAINT user_preferences_user_id_key UNIQUE (user_id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- Name: user_sessions user_sessions_session_token_key; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_session_token_key UNIQUE (session_token);


--
-- Name: user_settings user_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.user_settings
    ADD CONSTRAINT user_settings_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: web_search_queries web_search_queries_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.web_search_queries
    ADD CONSTRAINT web_search_queries_pkey PRIMARY KEY (id);


--
-- Name: web_searches web_searches_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.web_searches
    ADD CONSTRAINT web_searches_pkey PRIMARY KEY (id);


--
-- Name: workflow_step_transitions workflow_step_transitions_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.workflow_step_transitions
    ADD CONSTRAINT workflow_step_transitions_pkey PRIMARY KEY (id);


--
-- Name: workflow_steps workflow_steps_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.workflow_steps
    ADD CONSTRAINT workflow_steps_pkey PRIMARY KEY (id);


--
-- Name: workflows workflows_name_key; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.workflows
    ADD CONSTRAINT workflows_name_key UNIQUE (name);


--
-- Name: workflows workflows_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.workflows
    ADD CONSTRAINT workflows_pkey PRIMARY KEY (id);


--
-- Name: idx_ai_models_name_version; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE UNIQUE INDEX idx_ai_models_name_version ON public.ai_models USING btree (name, version);


--
-- Name: idx_ai_models_status; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_ai_models_status ON public.ai_models USING btree (status);


--
-- Name: idx_ai_models_type; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_ai_models_type ON public.ai_models USING btree (type);


--
-- Name: idx_ai_models_type_status; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_ai_models_type_status ON public.ai_models USING btree (type, status);


--
-- Name: idx_api_key_created; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_api_key_created ON public.api_keys USING btree (created_at);


--
-- Name: idx_api_key_status; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_api_key_status ON public.api_keys USING btree (status);


--
-- Name: idx_api_key_user; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_api_key_user ON public.api_keys USING btree (user_id);


--
-- Name: idx_auth_logs_created; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_auth_logs_created ON public.auth_logs USING btree (created_at);


--
-- Name: idx_auth_logs_event; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_auth_logs_event ON public.auth_logs USING btree (event_type);


--
-- Name: idx_auth_logs_method; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_auth_logs_method ON public.auth_logs USING btree (login_method);


--
-- Name: idx_auth_logs_status; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_auth_logs_status ON public.auth_logs USING btree (status);


--
-- Name: idx_auth_logs_user; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_auth_logs_user ON public.auth_logs USING btree (user_id);


--
-- Name: idx_cache_expiry; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_cache_expiry ON public.cache_entries USING btree (expires_at);


--
-- Name: idx_cache_key; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_cache_key ON public.cache_entries USING btree (key);


--
-- Name: idx_cache_type; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_cache_type ON public.cache_entries USING btree (type);


--
-- Name: idx_cache_type_expiry; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_cache_type_expiry ON public.cache_entries USING btree (type, expires_at);


--
-- Name: idx_device_controls_created; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_device_controls_created ON public.device_controls USING btree (created_at);


--
-- Name: idx_device_controls_device; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_device_controls_device ON public.device_controls USING btree (device_id);


--
-- Name: idx_device_controls_user; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_device_controls_user ON public.device_controls USING btree (user_id);


--
-- Name: idx_emotional_health_created; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_emotional_health_created ON public.emotional_health USING btree (created_at);


--
-- Name: idx_emotional_health_type; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_emotional_health_type ON public.emotional_health USING btree (emotion_type);


--
-- Name: idx_emotional_health_user; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_emotional_health_user ON public.emotional_health USING btree (user_id);


--
-- Name: idx_files_created_at; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_files_created_at ON public.files USING btree (created_at);


--
-- Name: idx_files_type; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_files_type ON public.files USING btree (file_type);


--
-- Name: idx_files_user_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_files_user_id ON public.files USING btree (user_id);


--
-- Name: idx_files_user_type; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_files_user_type ON public.files USING btree (user_id, file_type);


--
-- Name: idx_health_metrics_created; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_health_metrics_created ON public.health_metrics USING btree (created_at);


--
-- Name: idx_health_metrics_type; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_health_metrics_type ON public.health_metrics USING btree (metric_type);


--
-- Name: idx_health_metrics_user; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_health_metrics_user ON public.health_metrics USING btree (user_id);


--
-- Name: idx_model_metrics_model_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_model_metrics_model_id ON public.model_metrics USING btree (model_id);


--
-- Name: idx_model_metrics_model_name; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_model_metrics_model_name ON public.model_metrics USING btree (model_id, metric_name);


--
-- Name: idx_model_metrics_name; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_model_metrics_name ON public.model_metrics USING btree (metric_name);


--
-- Name: idx_model_metrics_timestamp; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_model_metrics_timestamp ON public.model_metrics USING btree ("timestamp");


--
-- Name: idx_model_usage_logs_created; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_model_usage_logs_created ON public.model_usage_logs USING btree (created_at);


--
-- Name: idx_model_usage_logs_model; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_model_usage_logs_model ON public.model_usage_logs USING btree (model_id);


--
-- Name: idx_model_usage_logs_task; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_model_usage_logs_task ON public.model_usage_logs USING btree (task_type);


--
-- Name: idx_model_usage_logs_user; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_model_usage_logs_user ON public.model_usage_logs USING btree (user_id);


--
-- Name: idx_notifications_created; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_notifications_created ON public.notifications USING btree (created_at);


--
-- Name: idx_notifications_type; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_notifications_type ON public.notifications USING btree (notification_type);


--
-- Name: idx_notifications_user; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_notifications_user ON public.notifications USING btree (user_id);


--
-- Name: idx_role_permissions_permission; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_role_permissions_permission ON public.role_permissions USING btree (permission_id);


--
-- Name: idx_role_permissions_role; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_role_permissions_role ON public.role_permissions USING btree (role_id);


--
-- Name: idx_sessions_active; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_sessions_active ON public.sessions USING btree (is_active);


--
-- Name: idx_sessions_expires; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_sessions_expires ON public.sessions USING btree (expires_at);


--
-- Name: idx_sessions_refresh; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_sessions_refresh ON public.sessions USING btree (refresh_token);


--
-- Name: idx_sessions_token; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_sessions_token ON public.sessions USING btree (session_token);


--
-- Name: idx_sessions_user; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_sessions_user ON public.sessions USING btree (user_id);


--
-- Name: idx_step_transitions_from; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_step_transitions_from ON public.workflow_step_transitions USING btree (from_step_id);


--
-- Name: idx_step_transitions_to; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_step_transitions_to ON public.workflow_step_transitions USING btree (to_step_id);


--
-- Name: idx_summaries_created_at; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_summaries_created_at ON public.summaries USING btree (created_at);


--
-- Name: idx_summaries_task_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE UNIQUE INDEX idx_summaries_task_id ON public.summaries USING btree (task_id);


--
-- Name: idx_summaries_type; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_summaries_type ON public.summaries USING btree (summary_type);


--
-- Name: idx_summarized_content_type_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE UNIQUE INDEX idx_summarized_content_type_id ON public.summarized_content USING btree (content_type, content_id);


--
-- Name: idx_system_logs_action; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_system_logs_action ON public.system_logs USING btree (action);


--
-- Name: idx_system_logs_timestamp; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_system_logs_timestamp ON public.system_logs USING btree ("timestamp");


--
-- Name: idx_system_logs_user_action; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_system_logs_user_action ON public.system_logs USING btree (user_id, action);


--
-- Name: idx_system_logs_user_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_system_logs_user_id ON public.system_logs USING btree (user_id);


--
-- Name: idx_tags_created_by; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_tags_created_by ON public.tags USING btree (created_by);


--
-- Name: idx_tags_name; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_tags_name ON public.tags USING btree (name);


--
-- Name: idx_task_tags_composite; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE UNIQUE INDEX idx_task_tags_composite ON public.task_tags USING btree (task_id, tag_id);


--
-- Name: idx_task_tags_tag_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_task_tags_tag_id ON public.task_tags USING btree (tag_id);


--
-- Name: idx_task_tags_task_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_task_tags_task_id ON public.task_tags USING btree (task_id);


--
-- Name: idx_user_preferences_user; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE UNIQUE INDEX idx_user_preferences_user ON public.user_preferences USING btree (user_id);


--
-- Name: idx_user_roles_role; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_user_roles_role ON public.user_roles USING btree (role_id);


--
-- Name: idx_user_roles_user; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_user_roles_user ON public.user_roles USING btree (user_id);


--
-- Name: idx_user_roles_user_role; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE UNIQUE INDEX idx_user_roles_user_role ON public.user_roles USING btree (user_id, role_id);


--
-- Name: idx_user_settings_key; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_user_settings_key ON public.user_settings USING btree (setting_key);


--
-- Name: idx_user_settings_user; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_user_settings_user ON public.user_settings USING btree (user_id);


--
-- Name: idx_users_created_at; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_users_created_at ON public.users USING btree (created_at);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE UNIQUE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: idx_users_last_login; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_users_last_login ON public.users USING btree (last_login);


--
-- Name: idx_users_username; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE UNIQUE INDEX idx_users_username ON public.users USING btree (username);


--
-- Name: idx_web_search_timestamp; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_web_search_timestamp ON public.web_search_queries USING btree ("timestamp");


--
-- Name: idx_web_search_type; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_web_search_type ON public.web_search_queries USING btree (search_type);


--
-- Name: idx_web_search_user_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_web_search_user_id ON public.web_search_queries USING btree (user_id);


--
-- Name: idx_web_search_user_type; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_web_search_user_type ON public.web_search_queries USING btree (user_id, search_type);


--
-- Name: idx_web_searches_created; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_web_searches_created ON public.web_searches USING btree (created_at);


--
-- Name: idx_web_searches_user; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_web_searches_user ON public.web_searches USING btree (user_id);


--
-- Name: idx_workflow_creator; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_workflow_creator ON public.workflows USING btree (creator_id);


--
-- Name: ix_data_archives_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX ix_data_archives_id ON public.data_archives USING btree (id);


--
-- Name: ix_data_requests_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX ix_data_requests_id ON public.data_requests USING btree (id);


--
-- Name: ix_feedback_comments_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX ix_feedback_comments_id ON public.feedback_comments USING btree (id);


--
-- Name: ix_feedback_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX ix_feedback_id ON public.feedback USING btree (id);


--
-- Name: ix_password_resets_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX ix_password_resets_id ON public.password_resets USING btree (id);


--
-- Name: ix_permissions_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX ix_permissions_id ON public.permissions USING btree (id);


--
-- Name: ix_privacy_settings_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX ix_privacy_settings_id ON public.privacy_settings USING btree (id);


--
-- Name: ix_roles_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX ix_roles_id ON public.roles USING btree (id);


--
-- Name: ix_summarized_content_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX ix_summarized_content_id ON public.summarized_content USING btree (id);


--
-- Name: ix_tags_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX ix_tags_id ON public.tags USING btree (id);


--
-- Name: ix_task_attachments_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX ix_task_attachments_id ON public.task_attachments USING btree (id);


--
-- Name: ix_task_categories_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX ix_task_categories_id ON public.task_categories USING btree (id);


--
-- Name: ix_task_comments_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX ix_task_comments_id ON public.task_comments USING btree (id);


--
-- Name: ix_task_history_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX ix_task_history_id ON public.task_history USING btree (id);


--
-- Name: ix_task_statuses_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX ix_task_statuses_id ON public.task_statuses USING btree (id);


--
-- Name: ix_tasks_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX ix_tasks_id ON public.tasks USING btree (id);


--
-- Name: ix_user_preferences_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX ix_user_preferences_id ON public.user_preferences USING btree (id);


--
-- Name: ix_user_sessions_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX ix_user_sessions_id ON public.user_sessions USING btree (id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX ix_users_id ON public.users USING btree (id);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: ix_workflow_step_transitions_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX ix_workflow_step_transitions_id ON public.workflow_step_transitions USING btree (id);


--
-- Name: ix_workflow_steps_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX ix_workflow_steps_id ON public.workflow_steps USING btree (id);


--
-- Name: ix_workflows_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX ix_workflows_id ON public.workflows USING btree (id);


--
-- Name: api_keys api_keys_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: auth_logs auth_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.auth_logs
    ADD CONSTRAINT auth_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: data_requests data_requests_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.data_requests
    ADD CONSTRAINT data_requests_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: device_controls device_controls_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.device_controls
    ADD CONSTRAINT device_controls_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: emotional_health emotional_health_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.emotional_health
    ADD CONSTRAINT emotional_health_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: feedback_comments feedback_comments_feedback_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.feedback_comments
    ADD CONSTRAINT feedback_comments_feedback_id_fkey FOREIGN KEY (feedback_id) REFERENCES public.feedback(id);


--
-- Name: feedback_comments feedback_comments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.feedback_comments
    ADD CONSTRAINT feedback_comments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: feedback feedback_resolved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_resolved_by_fkey FOREIGN KEY (resolved_by) REFERENCES public.users(id);


--
-- Name: feedback feedback_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: files files_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.files
    ADD CONSTRAINT files_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: health_metrics health_metrics_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.health_metrics
    ADD CONSTRAINT health_metrics_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: model_metrics model_metrics_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.model_metrics
    ADD CONSTRAINT model_metrics_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.ai_models(id) ON DELETE CASCADE;


--
-- Name: model_usage_logs model_usage_logs_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.model_usage_logs
    ADD CONSTRAINT model_usage_logs_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.ai_models(id) ON DELETE CASCADE;


--
-- Name: model_usage_logs model_usage_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.model_usage_logs
    ADD CONSTRAINT model_usage_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: password_resets password_resets_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.password_resets
    ADD CONSTRAINT password_resets_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: privacy_settings privacy_settings_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.privacy_settings
    ADD CONSTRAINT privacy_settings_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: role_permissions role_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: summaries summaries_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.summaries
    ADD CONSTRAINT summaries_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: system_logs system_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.system_logs
    ADD CONSTRAINT system_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: tags tags_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: task_attachments task_attachments_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.task_attachments
    ADD CONSTRAINT task_attachments_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_attachments task_attachments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.task_attachments
    ADD CONSTRAINT task_attachments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: task_comments task_comments_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.task_comments
    ADD CONSTRAINT task_comments_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_comments task_comments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.task_comments
    ADD CONSTRAINT task_comments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: task_history task_history_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.task_history
    ADD CONSTRAINT task_history_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_history task_history_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.task_history
    ADD CONSTRAINT task_history_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: task_tags task_tags_tag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.task_tags
    ADD CONSTRAINT task_tags_tag_id_fkey FOREIGN KEY (tag_id) REFERENCES public.tags(id) ON DELETE CASCADE;


--
-- Name: task_tags task_tags_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.task_tags
    ADD CONSTRAINT task_tags_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_assignee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_assignee_id_fkey FOREIGN KEY (assignee_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: tasks tasks_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.task_categories(id);


--
-- Name: tasks tasks_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_status_id_fkey FOREIGN KEY (status_id) REFERENCES public.task_statuses(id);


--
-- Name: tasks tasks_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_workflow_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_workflow_id_fkey FOREIGN KEY (workflow_id) REFERENCES public.workflows(id);


--
-- Name: user_preferences user_preferences_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.user_preferences
    ADD CONSTRAINT user_preferences_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_sessions user_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_settings user_settings_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.user_settings
    ADD CONSTRAINT user_settings_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: web_search_queries web_search_queries_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.web_search_queries
    ADD CONSTRAINT web_search_queries_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: web_searches web_searches_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.web_searches
    ADD CONSTRAINT web_searches_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: workflow_step_transitions workflow_step_transitions_from_step_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.workflow_step_transitions
    ADD CONSTRAINT workflow_step_transitions_from_step_id_fkey FOREIGN KEY (from_step_id) REFERENCES public.workflow_steps(id) ON DELETE CASCADE;


--
-- Name: workflow_step_transitions workflow_step_transitions_to_step_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.workflow_step_transitions
    ADD CONSTRAINT workflow_step_transitions_to_step_id_fkey FOREIGN KEY (to_step_id) REFERENCES public.workflow_steps(id) ON DELETE CASCADE;


--
-- Name: workflow_steps workflow_steps_workflow_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.workflow_steps
    ADD CONSTRAINT workflow_steps_workflow_id_fkey FOREIGN KEY (workflow_id) REFERENCES public.workflows(id) ON DELETE CASCADE;


--
-- Name: workflows workflows_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.workflows
    ADD CONSTRAINT workflows_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT ALL ON SCHEMA public TO ahmed;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: ahmed
--

ALTER DEFAULT PRIVILEGES FOR ROLE ahmed IN SCHEMA public GRANT ALL ON SEQUENCES TO ahmed;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON SEQUENCES TO ahmed;


--
-- Name: DEFAULT PRIVILEGES FOR TYPES; Type: DEFAULT ACL; Schema: public; Owner: ahmed
--

ALTER DEFAULT PRIVILEGES FOR ROLE ahmed IN SCHEMA public GRANT ALL ON TYPES TO ahmed;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON FUNCTIONS TO ahmed;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: ahmed
--

ALTER DEFAULT PRIVILEGES FOR ROLE ahmed IN SCHEMA public GRANT ALL ON TABLES TO ahmed;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT ALL ON TABLES TO ahmed;


--
-- PostgreSQL database dump complete
--

