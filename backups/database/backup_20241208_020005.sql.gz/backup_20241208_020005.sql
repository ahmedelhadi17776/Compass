--
-- PostgreSQL database dump
--

-- Dumped from database version 17.2
-- Dumped by pg_dump version 17.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: ahmed
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO ahmed;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: ahmed
--

COMMENT ON SCHEMA public IS '';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ai_models; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.ai_models (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    version character varying(50) NOT NULL,
    type character varying(50) NOT NULL,
    storage_path character varying(512),
    model_metadata json,
    status character varying(50),
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.ai_models OWNER TO ahmed;

--
-- Name: ai_models_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.ai_models_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ai_models_id_seq OWNER TO ahmed;

--
-- Name: ai_models_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.ai_models_id_seq OWNED BY public.ai_models.id;


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO ahmed;

--
-- Name: cache_entries; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.cache_entries (
    id integer NOT NULL,
    key character varying(255) NOT NULL,
    value json,
    type character varying(50),
    created_at timestamp without time zone,
    expires_at timestamp without time zone,
    is_compressed boolean,
    cache_metadata json
);


ALTER TABLE public.cache_entries OWNER TO ahmed;

--
-- Name: cache_entries_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.cache_entries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cache_entries_id_seq OWNER TO ahmed;

--
-- Name: cache_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.cache_entries_id_seq OWNED BY public.cache_entries.id;


--
-- Name: device_control_logs; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.device_control_logs (
    id integer NOT NULL,
    user_id integer,
    device_name character varying(255),
    device_type character varying(100),
    action character varying(100),
    parameters json,
    status character varying(50),
    error_message character varying(512),
    "timestamp" timestamp without time zone
);


ALTER TABLE public.device_control_logs OWNER TO ahmed;

--
-- Name: device_control_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.device_control_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.device_control_logs_id_seq OWNER TO ahmed;

--
-- Name: device_control_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.device_control_logs_id_seq OWNED BY public.device_control_logs.id;


--
-- Name: emotional_recognition; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.emotional_recognition (
    id integer NOT NULL,
    user_id integer,
    emotion character varying(50),
    confidence_level double precision,
    source_type character varying(50),
    source_data text,
    recognition_metadata json,
    "timestamp" timestamp without time zone
);


ALTER TABLE public.emotional_recognition OWNER TO ahmed;

--
-- Name: emotional_recognition_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.emotional_recognition_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.emotional_recognition_id_seq OWNER TO ahmed;

--
-- Name: emotional_recognition_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.emotional_recognition_id_seq OWNED BY public.emotional_recognition.id;


--
-- Name: health_metrics; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.health_metrics (
    id integer NOT NULL,
    user_id integer,
    metric_type character varying(100),
    metric_value double precision,
    metric_metadata json,
    "timestamp" timestamp without time zone
);


ALTER TABLE public.health_metrics OWNER TO ahmed;

--
-- Name: health_metrics_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.health_metrics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.health_metrics_id_seq OWNER TO ahmed;

--
-- Name: health_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.health_metrics_id_seq OWNED BY public.health_metrics.id;


--
-- Name: model_metrics; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.model_metrics (
    id integer NOT NULL,
    model_id integer,
    metric_name character varying(100),
    metric_value double precision,
    "timestamp" timestamp without time zone
);


ALTER TABLE public.model_metrics OWNER TO ahmed;

--
-- Name: model_metrics_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.model_metrics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.model_metrics_id_seq OWNER TO ahmed;

--
-- Name: model_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.model_metrics_id_seq OWNED BY public.model_metrics.id;


--
-- Name: model_usage_logs; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.model_usage_logs (
    id integer NOT NULL,
    model_id integer,
    user_id integer,
    task_type character varying(100),
    input_data json,
    output_data json,
    execution_time double precision,
    status character varying(50),
    error_message character varying(512),
    created_at timestamp without time zone
);


ALTER TABLE public.model_usage_logs OWNER TO ahmed;

--
-- Name: model_usage_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.model_usage_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.model_usage_logs_id_seq OWNER TO ahmed;

--
-- Name: model_usage_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.model_usage_logs_id_seq OWNED BY public.model_usage_logs.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.notifications (
    id integer NOT NULL,
    user_id integer NOT NULL,
    title character varying NOT NULL,
    message text NOT NULL,
    type character varying NOT NULL,
    is_read boolean,
    notification_metadata json,
    created_at timestamp with time zone,
    read_at timestamp with time zone
);


ALTER TABLE public.notifications OWNER TO ahmed;

--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.notifications_id_seq OWNER TO ahmed;

--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.notifications_id_seq OWNED BY public.notifications.id;


--
-- Name: password_resets; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.password_resets (
    id integer NOT NULL,
    user_id integer NOT NULL,
    token character varying NOT NULL,
    created_at timestamp with time zone,
    expires_at timestamp with time zone NOT NULL,
    used boolean
);


ALTER TABLE public.password_resets OWNER TO ahmed;

--
-- Name: password_resets_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.password_resets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.password_resets_id_seq OWNER TO ahmed;

--
-- Name: password_resets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.password_resets_id_seq OWNED BY public.password_resets.id;


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.permissions (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(255),
    resource character varying(50),
    action character varying(50)
);


ALTER TABLE public.permissions OWNER TO ahmed;

--
-- Name: permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.permissions_id_seq OWNER TO ahmed;

--
-- Name: permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.permissions_id_seq OWNED BY public.permissions.id;


--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.role_permissions (
    role_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.role_permissions OWNER TO ahmed;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(255)
);


ALTER TABLE public.roles OWNER TO ahmed;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.roles_id_seq OWNER TO ahmed;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: summarized_content; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.summarized_content (
    id integer NOT NULL,
    task_id integer,
    summary text NOT NULL,
    key_points text,
    generated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.summarized_content OWNER TO ahmed;

--
-- Name: summarized_content_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.summarized_content_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.summarized_content_id_seq OWNER TO ahmed;

--
-- Name: summarized_content_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.summarized_content_id_seq OWNED BY public.summarized_content.id;


--
-- Name: tags; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.tags (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    description text,
    color_code character varying(7),
    created_by integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.tags OWNER TO ahmed;

--
-- Name: tags_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.tags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tags_id_seq OWNER TO ahmed;

--
-- Name: tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.tags_id_seq OWNED BY public.tags.id;


--
-- Name: task_attachments; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.task_attachments (
    id integer NOT NULL,
    task_id integer NOT NULL,
    file_name character varying(255) NOT NULL,
    file_path character varying(1000) NOT NULL,
    file_type character varying(128),
    file_size integer,
    uploaded_by integer NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.task_attachments OWNER TO ahmed;

--
-- Name: task_attachments_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.task_attachments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.task_attachments_id_seq OWNER TO ahmed;

--
-- Name: task_attachments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.task_attachments_id_seq OWNED BY public.task_attachments.id;


--
-- Name: task_categories; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.task_categories (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(255),
    color_code character varying(7),
    icon character varying(50),
    parent_id integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.task_categories OWNER TO ahmed;

--
-- Name: task_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.task_categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.task_categories_id_seq OWNER TO ahmed;

--
-- Name: task_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.task_categories_id_seq OWNED BY public.task_categories.id;


--
-- Name: task_comments; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.task_comments (
    id integer NOT NULL,
    task_id integer NOT NULL,
    user_id integer NOT NULL,
    content text NOT NULL,
    parent_id integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.task_comments OWNER TO ahmed;

--
-- Name: task_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.task_comments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.task_comments_id_seq OWNER TO ahmed;

--
-- Name: task_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.task_comments_id_seq OWNED BY public.task_comments.id;


--
-- Name: task_history; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.task_history (
    id integer NOT NULL,
    task_id integer NOT NULL,
    user_id integer NOT NULL,
    change_type character varying(50) NOT NULL,
    old_value json,
    new_value json,
    created_at timestamp with time zone
);


ALTER TABLE public.task_history OWNER TO ahmed;

--
-- Name: task_history_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.task_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.task_history_id_seq OWNER TO ahmed;

--
-- Name: task_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.task_history_id_seq OWNED BY public.task_history.id;


--
-- Name: task_priorities; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.task_priorities (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(255),
    weight integer,
    color_code character varying(7),
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.task_priorities OWNER TO ahmed;

--
-- Name: task_priorities_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.task_priorities_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.task_priorities_id_seq OWNER TO ahmed;

--
-- Name: task_priorities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.task_priorities_id_seq OWNED BY public.task_priorities.id;


--
-- Name: task_status; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.task_status (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    description character varying(255),
    color_code character varying(7),
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.task_status OWNER TO ahmed;

--
-- Name: task_status_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.task_status_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.task_status_id_seq OWNER TO ahmed;

--
-- Name: task_status_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.task_status_id_seq OWNED BY public.task_status.id;


--
-- Name: task_tags; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.task_tags (
    task_id integer NOT NULL,
    tag_id integer NOT NULL
);


ALTER TABLE public.task_tags OWNER TO ahmed;

--
-- Name: tasks; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.tasks (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    status_id integer NOT NULL,
    priority_id integer NOT NULL,
    category_id integer,
    due_date timestamp with time zone,
    start_date timestamp with time zone,
    completion_date timestamp with time zone,
    estimated_hours double precision,
    actual_hours double precision,
    external_sync_id character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    user_id integer NOT NULL,
    workflow_step_id integer,
    CONSTRAINT ck_tasks_completion_after_creation CHECK ((completion_date > created_at)),
    CONSTRAINT ck_tasks_due_date_after_creation CHECK ((due_date > created_at)),
    CONSTRAINT tasks_actual_hours_check CHECK ((actual_hours >= (0)::double precision)),
    CONSTRAINT tasks_estimated_hours_check CHECK ((estimated_hours >= (0)::double precision))
);


ALTER TABLE public.tasks OWNER TO ahmed;

--
-- Name: tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tasks_id_seq OWNER TO ahmed;

--
-- Name: tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.tasks_id_seq OWNED BY public.tasks.id;


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.user_roles (
    id integer NOT NULL,
    user_id integer NOT NULL,
    role_id integer NOT NULL
);


ALTER TABLE public.user_roles OWNER TO ahmed;

--
-- Name: user_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.user_roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_roles_id_seq OWNER TO ahmed;

--
-- Name: user_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.user_roles_id_seq OWNED BY public.user_roles.id;


--
-- Name: user_sessions; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.user_sessions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    session_token character varying NOT NULL,
    refresh_token character varying,
    expires_at timestamp with time zone NOT NULL,
    is_active boolean,
    created_at timestamp with time zone,
    ended_at timestamp with time zone,
    device_info json,
    ip_address character varying(45)
);


ALTER TABLE public.user_sessions OWNER TO ahmed;

--
-- Name: user_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.user_sessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_sessions_id_seq OWNER TO ahmed;

--
-- Name: user_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.user_sessions_id_seq OWNED BY public.user_sessions.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    hashed_password character varying(255) NOT NULL,
    is_active boolean,
    created_at timestamp without time zone,
    full_name character varying(100),
    is_verified boolean DEFAULT false,
    last_login timestamp without time zone,
    username character varying(50) NOT NULL,
    is_locked boolean
);


ALTER TABLE public.users OWNER TO ahmed;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO ahmed;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: web_search_queries; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.web_search_queries (
    id integer NOT NULL,
    user_id integer,
    query_text text NOT NULL,
    search_type character varying(50),
    filters json,
    results json,
    result_count integer,
    execution_time double precision,
    "timestamp" timestamp without time zone
);


ALTER TABLE public.web_search_queries OWNER TO ahmed;

--
-- Name: web_search_queries_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.web_search_queries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.web_search_queries_id_seq OWNER TO ahmed;

--
-- Name: web_search_queries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.web_search_queries_id_seq OWNED BY public.web_search_queries.id;


--
-- Name: workflow_step_transitions; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.workflow_step_transitions (
    from_step_id integer NOT NULL,
    to_step_id integer NOT NULL
);


ALTER TABLE public.workflow_step_transitions OWNER TO ahmed;

--
-- Name: workflow_steps; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.workflow_steps (
    id integer NOT NULL,
    workflow_id integer,
    name character varying(100) NOT NULL,
    description text,
    "order" integer,
    requirements json,
    auto_advance boolean,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.workflow_steps OWNER TO ahmed;

--
-- Name: workflow_steps_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.workflow_steps_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.workflow_steps_id_seq OWNER TO ahmed;

--
-- Name: workflow_steps_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.workflow_steps_id_seq OWNED BY public.workflow_steps.id;


--
-- Name: workflows; Type: TABLE; Schema: public; Owner: ahmed
--

CREATE TABLE public.workflows (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    is_active boolean,
    created_by integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.workflows OWNER TO ahmed;

--
-- Name: workflows_id_seq; Type: SEQUENCE; Schema: public; Owner: ahmed
--

CREATE SEQUENCE public.workflows_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.workflows_id_seq OWNER TO ahmed;

--
-- Name: workflows_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: ahmed
--

ALTER SEQUENCE public.workflows_id_seq OWNED BY public.workflows.id;


--
-- Name: ai_models id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.ai_models ALTER COLUMN id SET DEFAULT nextval('public.ai_models_id_seq'::regclass);


--
-- Name: cache_entries id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.cache_entries ALTER COLUMN id SET DEFAULT nextval('public.cache_entries_id_seq'::regclass);


--
-- Name: device_control_logs id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.device_control_logs ALTER COLUMN id SET DEFAULT nextval('public.device_control_logs_id_seq'::regclass);


--
-- Name: emotional_recognition id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.emotional_recognition ALTER COLUMN id SET DEFAULT nextval('public.emotional_recognition_id_seq'::regclass);


--
-- Name: health_metrics id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.health_metrics ALTER COLUMN id SET DEFAULT nextval('public.health_metrics_id_seq'::regclass);


--
-- Name: model_metrics id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.model_metrics ALTER COLUMN id SET DEFAULT nextval('public.model_metrics_id_seq'::regclass);


--
-- Name: model_usage_logs id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.model_usage_logs ALTER COLUMN id SET DEFAULT nextval('public.model_usage_logs_id_seq'::regclass);


--
-- Name: notifications id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.notifications ALTER COLUMN id SET DEFAULT nextval('public.notifications_id_seq'::regclass);


--
-- Name: password_resets id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.password_resets ALTER COLUMN id SET DEFAULT nextval('public.password_resets_id_seq'::regclass);


--
-- Name: permissions id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.permissions ALTER COLUMN id SET DEFAULT nextval('public.permissions_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: summarized_content id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.summarized_content ALTER COLUMN id SET DEFAULT nextval('public.summarized_content_id_seq'::regclass);


--
-- Name: tags id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.tags ALTER COLUMN id SET DEFAULT nextval('public.tags_id_seq'::regclass);


--
-- Name: task_attachments id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.task_attachments ALTER COLUMN id SET DEFAULT nextval('public.task_attachments_id_seq'::regclass);


--
-- Name: task_categories id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.task_categories ALTER COLUMN id SET DEFAULT nextval('public.task_categories_id_seq'::regclass);


--
-- Name: task_comments id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.task_comments ALTER COLUMN id SET DEFAULT nextval('public.task_comments_id_seq'::regclass);


--
-- Name: task_history id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.task_history ALTER COLUMN id SET DEFAULT nextval('public.task_history_id_seq'::regclass);


--
-- Name: task_priorities id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.task_priorities ALTER COLUMN id SET DEFAULT nextval('public.task_priorities_id_seq'::regclass);


--
-- Name: task_status id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.task_status ALTER COLUMN id SET DEFAULT nextval('public.task_status_id_seq'::regclass);


--
-- Name: tasks id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.tasks ALTER COLUMN id SET DEFAULT nextval('public.tasks_id_seq'::regclass);


--
-- Name: user_roles id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.user_roles ALTER COLUMN id SET DEFAULT nextval('public.user_roles_id_seq'::regclass);


--
-- Name: user_sessions id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.user_sessions ALTER COLUMN id SET DEFAULT nextval('public.user_sessions_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: web_search_queries id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.web_search_queries ALTER COLUMN id SET DEFAULT nextval('public.web_search_queries_id_seq'::regclass);


--
-- Name: workflow_steps id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.workflow_steps ALTER COLUMN id SET DEFAULT nextval('public.workflow_steps_id_seq'::regclass);


--
-- Name: workflows id; Type: DEFAULT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.workflows ALTER COLUMN id SET DEFAULT nextval('public.workflows_id_seq'::regclass);


--
-- Data for Name: ai_models; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.ai_models (id, name, version, type, storage_path, model_metadata, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.alembic_version (version_num) FROM stdin;
07d1eb1f1189
\.


--
-- Data for Name: cache_entries; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.cache_entries (id, key, value, type, created_at, expires_at, is_compressed, cache_metadata) FROM stdin;
\.


--
-- Data for Name: device_control_logs; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.device_control_logs (id, user_id, device_name, device_type, action, parameters, status, error_message, "timestamp") FROM stdin;
\.


--
-- Data for Name: emotional_recognition; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.emotional_recognition (id, user_id, emotion, confidence_level, source_type, source_data, recognition_metadata, "timestamp") FROM stdin;
\.


--
-- Data for Name: health_metrics; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.health_metrics (id, user_id, metric_type, metric_value, metric_metadata, "timestamp") FROM stdin;
\.


--
-- Data for Name: model_metrics; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.model_metrics (id, model_id, metric_name, metric_value, "timestamp") FROM stdin;
\.


--
-- Data for Name: model_usage_logs; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.model_usage_logs (id, model_id, user_id, task_type, input_data, output_data, execution_time, status, error_message, created_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.notifications (id, user_id, title, message, type, is_read, notification_metadata, created_at, read_at) FROM stdin;
\.


--
-- Data for Name: password_resets; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.password_resets (id, user_id, token, created_at, expires_at, used) FROM stdin;
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.permissions (id, name, description, resource, action) FROM stdin;
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.role_permissions (role_id, permission_id) FROM stdin;
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.roles (id, name, description) FROM stdin;
\.


--
-- Data for Name: summarized_content; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.summarized_content (id, task_id, summary, key_points, generated_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tags; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.tags (id, name, description, color_code, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: task_attachments; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.task_attachments (id, task_id, file_name, file_path, file_type, file_size, uploaded_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: task_categories; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.task_categories (id, name, description, color_code, icon, parent_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: task_comments; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.task_comments (id, task_id, user_id, content, parent_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: task_history; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.task_history (id, task_id, user_id, change_type, old_value, new_value, created_at) FROM stdin;
\.


--
-- Data for Name: task_priorities; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.task_priorities (id, name, description, weight, color_code, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: task_status; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.task_status (id, name, description, color_code, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: task_tags; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.task_tags (task_id, tag_id) FROM stdin;
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.tasks (id, title, description, status_id, priority_id, category_id, due_date, start_date, completion_date, estimated_hours, actual_hours, external_sync_id, created_at, updated_at, user_id, workflow_step_id) FROM stdin;
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.user_roles (id, user_id, role_id) FROM stdin;
\.


--
-- Data for Name: user_sessions; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.user_sessions (id, user_id, session_token, refresh_token, expires_at, is_active, created_at, ended_at, device_info, ip_address) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.users (id, email, hashed_password, is_active, created_at, full_name, is_verified, last_login, username, is_locked) FROM stdin;
7	test@example.com	$2b$12$voSv4Ld2sGCaYnsmqkgRo.KDlG4fS5IGzDWkKFUTSJo2YrfdZXqmm	t	2024-11-30 17:32:38.044599		f	\N	test	\N
10	admin@example.com	$2b$12$ZT4B9JT1beLy4dz5.VTXXeHFHtt/ZX57J7VusV3GPBFXrhgcQEVz.	t	2024-12-01 05:01:02.961484	Admin User	f	\N	admin	\N
\.


--
-- Data for Name: web_search_queries; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.web_search_queries (id, user_id, query_text, search_type, filters, results, result_count, execution_time, "timestamp") FROM stdin;
\.


--
-- Data for Name: workflow_step_transitions; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.workflow_step_transitions (from_step_id, to_step_id) FROM stdin;
\.


--
-- Data for Name: workflow_steps; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.workflow_steps (id, workflow_id, name, description, "order", requirements, auto_advance, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: workflows; Type: TABLE DATA; Schema: public; Owner: ahmed
--

COPY public.workflows (id, name, description, is_active, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Name: ai_models_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.ai_models_id_seq', 1, false);


--
-- Name: cache_entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.cache_entries_id_seq', 1, false);


--
-- Name: device_control_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.device_control_logs_id_seq', 1, false);


--
-- Name: emotional_recognition_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.emotional_recognition_id_seq', 1, false);


--
-- Name: health_metrics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.health_metrics_id_seq', 1, false);


--
-- Name: model_metrics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.model_metrics_id_seq', 1, false);


--
-- Name: model_usage_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.model_usage_logs_id_seq', 1, false);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.notifications_id_seq', 1, false);


--
-- Name: password_resets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.password_resets_id_seq', 1, false);


--
-- Name: permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.permissions_id_seq', 1, false);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.roles_id_seq', 1, false);


--
-- Name: summarized_content_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.summarized_content_id_seq', 1, false);


--
-- Name: tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.tags_id_seq', 1, false);


--
-- Name: task_attachments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.task_attachments_id_seq', 1, false);


--
-- Name: task_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.task_categories_id_seq', 1, false);


--
-- Name: task_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.task_comments_id_seq', 1, false);


--
-- Name: task_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.task_history_id_seq', 1, false);


--
-- Name: task_priorities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.task_priorities_id_seq', 1, false);


--
-- Name: task_status_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.task_status_id_seq', 1, false);


--
-- Name: tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.tasks_id_seq', 1, false);


--
-- Name: user_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.user_roles_id_seq', 1, false);


--
-- Name: user_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.user_sessions_id_seq', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.users_id_seq', 11, true);


--
-- Name: web_search_queries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.web_search_queries_id_seq', 1, false);


--
-- Name: workflow_steps_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.workflow_steps_id_seq', 1, false);


--
-- Name: workflows_id_seq; Type: SEQUENCE SET; Schema: public; Owner: ahmed
--

SELECT pg_catalog.setval('public.workflows_id_seq', 1, false);


--
-- Name: ai_models ai_models_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.ai_models
    ADD CONSTRAINT ai_models_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: cache_entries cache_entries_key_key; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.cache_entries
    ADD CONSTRAINT cache_entries_key_key UNIQUE (key);


--
-- Name: cache_entries cache_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.cache_entries
    ADD CONSTRAINT cache_entries_pkey PRIMARY KEY (id);


--
-- Name: device_control_logs device_control_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.device_control_logs
    ADD CONSTRAINT device_control_logs_pkey PRIMARY KEY (id);


--
-- Name: emotional_recognition emotional_recognition_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.emotional_recognition
    ADD CONSTRAINT emotional_recognition_pkey PRIMARY KEY (id);


--
-- Name: health_metrics health_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.health_metrics
    ADD CONSTRAINT health_metrics_pkey PRIMARY KEY (id);


--
-- Name: model_metrics model_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.model_metrics
    ADD CONSTRAINT model_metrics_pkey PRIMARY KEY (id);


--
-- Name: model_usage_logs model_usage_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.model_usage_logs
    ADD CONSTRAINT model_usage_logs_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: password_resets password_resets_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.password_resets
    ADD CONSTRAINT password_resets_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (role_id, permission_id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: summarized_content summarized_content_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.summarized_content
    ADD CONSTRAINT summarized_content_pkey PRIMARY KEY (id);


--
-- Name: summarized_content summarized_content_task_id_key; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.summarized_content
    ADD CONSTRAINT summarized_content_task_id_key UNIQUE (task_id);


--
-- Name: tags tags_name_key; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_name_key UNIQUE (name);


--
-- Name: tags tags_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (id);


--
-- Name: task_attachments task_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.task_attachments
    ADD CONSTRAINT task_attachments_pkey PRIMARY KEY (id);


--
-- Name: task_categories task_categories_name_key; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.task_categories
    ADD CONSTRAINT task_categories_name_key UNIQUE (name);


--
-- Name: task_categories task_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.task_categories
    ADD CONSTRAINT task_categories_pkey PRIMARY KEY (id);


--
-- Name: task_comments task_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.task_comments
    ADD CONSTRAINT task_comments_pkey PRIMARY KEY (id);


--
-- Name: task_history task_history_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.task_history
    ADD CONSTRAINT task_history_pkey PRIMARY KEY (id);


--
-- Name: task_priorities task_priorities_name_key; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.task_priorities
    ADD CONSTRAINT task_priorities_name_key UNIQUE (name);


--
-- Name: task_priorities task_priorities_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.task_priorities
    ADD CONSTRAINT task_priorities_pkey PRIMARY KEY (id);


--
-- Name: task_status task_status_name_key; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.task_status
    ADD CONSTRAINT task_status_name_key UNIQUE (name);


--
-- Name: task_status task_status_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.task_status
    ADD CONSTRAINT task_status_pkey PRIMARY KEY (id);


--
-- Name: task_tags task_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.task_tags
    ADD CONSTRAINT task_tags_pkey PRIMARY KEY (task_id, tag_id);


--
-- Name: tasks tasks_external_sync_id_key; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_external_sync_id_key UNIQUE (external_sync_id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- Name: user_sessions user_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_pkey PRIMARY KEY (id);


--
-- Name: user_sessions user_sessions_refresh_token_key; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_refresh_token_key UNIQUE (refresh_token);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: web_search_queries web_search_queries_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.web_search_queries
    ADD CONSTRAINT web_search_queries_pkey PRIMARY KEY (id);


--
-- Name: workflow_step_transitions workflow_step_transitions_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.workflow_step_transitions
    ADD CONSTRAINT workflow_step_transitions_pkey PRIMARY KEY (from_step_id, to_step_id);


--
-- Name: workflow_steps workflow_steps_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.workflow_steps
    ADD CONSTRAINT workflow_steps_pkey PRIMARY KEY (id);


--
-- Name: workflows workflows_pkey; Type: CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.workflows
    ADD CONSTRAINT workflows_pkey PRIMARY KEY (id);


--
-- Name: idx_ai_models_name_version; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE UNIQUE INDEX idx_ai_models_name_version ON public.ai_models USING btree (name, version);


--
-- Name: idx_ai_models_status; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_ai_models_status ON public.ai_models USING btree (status);


--
-- Name: idx_ai_models_type; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_ai_models_type ON public.ai_models USING btree (type);


--
-- Name: idx_cache_expiry; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_cache_expiry ON public.cache_entries USING btree (expires_at);


--
-- Name: idx_cache_key; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_cache_key ON public.cache_entries USING btree (key);


--
-- Name: idx_cache_type; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_cache_type ON public.cache_entries USING btree (type);


--
-- Name: idx_device_logs_device; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_device_logs_device ON public.device_control_logs USING btree (device_name);


--
-- Name: idx_device_logs_timestamp; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_device_logs_timestamp ON public.device_control_logs USING btree ("timestamp");


--
-- Name: idx_device_logs_user_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_device_logs_user_id ON public.device_control_logs USING btree (user_id);


--
-- Name: idx_emotional_recog_emotion; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_emotional_recog_emotion ON public.emotional_recognition USING btree (emotion);


--
-- Name: idx_emotional_recog_timestamp; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_emotional_recog_timestamp ON public.emotional_recognition USING btree ("timestamp");


--
-- Name: idx_emotional_recog_user_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_emotional_recog_user_id ON public.emotional_recognition USING btree (user_id);


--
-- Name: idx_health_metrics_timestamp; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_health_metrics_timestamp ON public.health_metrics USING btree ("timestamp");


--
-- Name: idx_health_metrics_type; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_health_metrics_type ON public.health_metrics USING btree (metric_type);


--
-- Name: idx_health_metrics_user_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_health_metrics_user_id ON public.health_metrics USING btree (user_id);


--
-- Name: idx_model_metrics_model_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_model_metrics_model_id ON public.model_metrics USING btree (model_id);


--
-- Name: idx_model_metrics_timestamp; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_model_metrics_timestamp ON public.model_metrics USING btree ("timestamp");


--
-- Name: idx_model_usage_created_at; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_model_usage_created_at ON public.model_usage_logs USING btree (created_at);


--
-- Name: idx_model_usage_model_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_model_usage_model_id ON public.model_usage_logs USING btree (model_id);


--
-- Name: idx_model_usage_user_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_model_usage_user_id ON public.model_usage_logs USING btree (user_id);


--
-- Name: idx_step_transitions_from; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_step_transitions_from ON public.workflow_step_transitions USING btree (from_step_id);


--
-- Name: idx_step_transitions_to; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_step_transitions_to ON public.workflow_step_transitions USING btree (to_step_id);


--
-- Name: idx_summarized_content_task_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_summarized_content_task_id ON public.summarized_content USING btree (task_id);


--
-- Name: idx_tags_created_by; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_tags_created_by ON public.tags USING btree (created_by);


--
-- Name: idx_tags_name; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_tags_name ON public.tags USING btree (name);


--
-- Name: idx_task_tags_tag_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_task_tags_tag_id ON public.task_tags USING btree (tag_id);


--
-- Name: idx_task_tags_task_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_task_tags_task_id ON public.task_tags USING btree (task_id);


--
-- Name: idx_tasks_created_at; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_tasks_created_at ON public.tasks USING btree (created_at);


--
-- Name: idx_tasks_due_date; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_tasks_due_date ON public.tasks USING btree (due_date);


--
-- Name: idx_tasks_status_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_tasks_status_id ON public.tasks USING btree (status_id);


--
-- Name: idx_tasks_user_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_tasks_user_id ON public.tasks USING btree (user_id);


--
-- Name: idx_web_search_timestamp; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_web_search_timestamp ON public.web_search_queries USING btree ("timestamp");


--
-- Name: idx_web_search_user_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_web_search_user_id ON public.web_search_queries USING btree (user_id);


--
-- Name: idx_workflow_steps_workflow_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_workflow_steps_workflow_id ON public.workflow_steps USING btree (workflow_id);


--
-- Name: idx_workflows_created_by; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_workflows_created_by ON public.workflows USING btree (created_by);


--
-- Name: idx_workflows_name; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX idx_workflows_name ON public.workflows USING btree (name);


--
-- Name: ix_notifications_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX ix_notifications_id ON public.notifications USING btree (id);


--
-- Name: ix_password_resets_expires_at; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX ix_password_resets_expires_at ON public.password_resets USING btree (expires_at);


--
-- Name: ix_password_resets_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX ix_password_resets_id ON public.password_resets USING btree (id);


--
-- Name: ix_password_resets_token; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE UNIQUE INDEX ix_password_resets_token ON public.password_resets USING btree (token);


--
-- Name: ix_password_resets_user_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX ix_password_resets_user_id ON public.password_resets USING btree (user_id);


--
-- Name: ix_permissions_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX ix_permissions_id ON public.permissions USING btree (id);


--
-- Name: ix_permissions_name; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE UNIQUE INDEX ix_permissions_name ON public.permissions USING btree (name);


--
-- Name: ix_roles_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX ix_roles_id ON public.roles USING btree (id);


--
-- Name: ix_roles_name; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE UNIQUE INDEX ix_roles_name ON public.roles USING btree (name);


--
-- Name: ix_tags_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX ix_tags_id ON public.tags USING btree (id);


--
-- Name: ix_task_attachments_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX ix_task_attachments_id ON public.task_attachments USING btree (id);


--
-- Name: ix_task_categories_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX ix_task_categories_id ON public.task_categories USING btree (id);


--
-- Name: ix_task_comments_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX ix_task_comments_id ON public.task_comments USING btree (id);


--
-- Name: ix_task_history_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX ix_task_history_id ON public.task_history USING btree (id);


--
-- Name: ix_task_priorities_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX ix_task_priorities_id ON public.task_priorities USING btree (id);


--
-- Name: ix_task_status_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX ix_task_status_id ON public.task_status USING btree (id);


--
-- Name: ix_user_roles_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX ix_user_roles_id ON public.user_roles USING btree (id);


--
-- Name: ix_user_sessions_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX ix_user_sessions_id ON public.user_sessions USING btree (id);


--
-- Name: ix_user_sessions_session_token; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE UNIQUE INDEX ix_user_sessions_session_token ON public.user_sessions USING btree (session_token);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_id; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE INDEX ix_users_id ON public.users USING btree (id);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: ahmed
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: device_control_logs device_control_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.device_control_logs
    ADD CONSTRAINT device_control_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: emotional_recognition emotional_recognition_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.emotional_recognition
    ADD CONSTRAINT emotional_recognition_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: health_metrics health_metrics_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.health_metrics
    ADD CONSTRAINT health_metrics_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: model_metrics model_metrics_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.model_metrics
    ADD CONSTRAINT model_metrics_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.ai_models(id);


--
-- Name: model_usage_logs model_usage_logs_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.model_usage_logs
    ADD CONSTRAINT model_usage_logs_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.ai_models(id);


--
-- Name: model_usage_logs model_usage_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.model_usage_logs
    ADD CONSTRAINT model_usage_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: password_resets password_resets_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.password_resets
    ADD CONSTRAINT password_resets_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: summarized_content summarized_content_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.summarized_content
    ADD CONSTRAINT summarized_content_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: tags tags_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: task_attachments task_attachments_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.task_attachments
    ADD CONSTRAINT task_attachments_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_attachments task_attachments_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.task_attachments
    ADD CONSTRAINT task_attachments_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: task_categories task_categories_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.task_categories
    ADD CONSTRAINT task_categories_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.task_categories(id);


--
-- Name: task_comments task_comments_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.task_comments
    ADD CONSTRAINT task_comments_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.task_comments(id);


--
-- Name: task_comments task_comments_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.task_comments
    ADD CONSTRAINT task_comments_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_comments task_comments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.task_comments
    ADD CONSTRAINT task_comments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: task_history task_history_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.task_history
    ADD CONSTRAINT task_history_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_history task_history_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.task_history
    ADD CONSTRAINT task_history_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: task_tags task_tags_tag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.task_tags
    ADD CONSTRAINT task_tags_tag_id_fkey FOREIGN KEY (tag_id) REFERENCES public.tags(id) ON DELETE CASCADE;


--
-- Name: task_tags task_tags_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.task_tags
    ADD CONSTRAINT task_tags_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.task_categories(id) ON DELETE SET NULL;


--
-- Name: tasks tasks_priority_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_priority_id_fkey FOREIGN KEY (priority_id) REFERENCES public.task_priorities(id) ON DELETE RESTRICT;


--
-- Name: tasks tasks_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_status_id_fkey FOREIGN KEY (status_id) REFERENCES public.task_status(id) ON DELETE RESTRICT;


--
-- Name: tasks tasks_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_workflow_step_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_workflow_step_id_fkey FOREIGN KEY (workflow_step_id) REFERENCES public.workflow_steps(id) ON DELETE SET NULL;


--
-- Name: user_roles user_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_sessions user_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.user_sessions
    ADD CONSTRAINT user_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: web_search_queries web_search_queries_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.web_search_queries
    ADD CONSTRAINT web_search_queries_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: workflow_step_transitions workflow_step_transitions_from_step_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.workflow_step_transitions
    ADD CONSTRAINT workflow_step_transitions_from_step_id_fkey FOREIGN KEY (from_step_id) REFERENCES public.workflow_steps(id) ON DELETE CASCADE;


--
-- Name: workflow_step_transitions workflow_step_transitions_to_step_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.workflow_step_transitions
    ADD CONSTRAINT workflow_step_transitions_to_step_id_fkey FOREIGN KEY (to_step_id) REFERENCES public.workflow_steps(id) ON DELETE CASCADE;


--
-- Name: workflow_steps workflow_steps_workflow_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.workflow_steps
    ADD CONSTRAINT workflow_steps_workflow_id_fkey FOREIGN KEY (workflow_id) REFERENCES public.workflows(id) ON DELETE CASCADE;


--
-- Name: workflows workflows_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ahmed
--

ALTER TABLE ONLY public.workflows
    ADD CONSTRAINT workflows_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: ahmed
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

